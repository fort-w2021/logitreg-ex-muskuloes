#' logitreg: a fairly pointless practice project
#'
#' This could be the description from `DESCRIPTION`.
#'
#' Here you write some more detail on what the package does and why it's
#' relevant, list and describe the most important functions, and point users
#' to additional ressources like your papers and package vignettes etc.
#'
#' @name logitreg-package
#' @docType package
NULL
