#' @include utils.R
NULL
#' @include neg_loglik.R
NULL

################################################################################


#' Logistic regression model
#'
#' Maximum likelihood estimation of logistic regression with [stats::optim()].
#'
#' @param design either a model matrix or a model formula.
#' @return an object of class `logitreg`, for which
#'   [predict][predict.logitreg()], [fitted][fitted.logitreg()], and
#'   [plot][plot.logitreg()] methods are defined. Objects of class `logitreg`
#'   are lists with entries
#'   - `coefficients`: the estimated regression coefficients,
#'   - `fitted`: the estimated probabilites for \eqn{y=1},
#'   - `data`: the supplied data, a list of `design` matrix and `response` vector
#' @export
logitreg <- function(design, ...) UseMethod("logitreg")

#' @param ... optional arguments handed over to [stats::optim()]
#' @param response the response vector (0/1)
#' @param method see [stats::optim()], defaults to "BFGS".
#' @rdname logitreg
#' @import checkmate
#' @importFrom stats complete.cases optim
logitreg.default <- function(design, response, method = "BFGS", ...) {
  assert_matrix(design, mode = "numeric", min.rows = 1)
  assert_numeric(response)
  assert_choice(method, choices = eval(formals(optim)$method))
  ## remove NAs
  no_na <- complete.cases(design) & !is.na(response)
  design <- design[no_na, , drop = FALSE]
  response <- response[no_na]

  if (sum(no_na) < NCOL(design)) {
    stop("not enough non-missing data to fit the model.")
  }
  # check binary response:
  stopifnot(all(response %in% c(0, 1)))

  coef <- rep(0, NCOL(design))
  optim_res <- optim(
    par = coef, fn = neg_loglik, gr = neg_loglik_deriv,
    design = design, response = response,
    method = method, hessian = TRUE, ...
  )

  if (optim_res$conv > 0) {
    warning("`optim` did not converge, error code: ", optim_res$conv)
  }

  coef <- optim_res$par
  names(coef) <- colnames(design)

  fitted <- logistic(design %*% coef)

  res <- list(
    coefficients = coef,
    fitted = fitted,
    data = list(
      design = design,
      response = response
    )
  )
  class(res) <- "logitreg"
  res
}


#' @param data a list or data.frame holding the variables in the formula. If not
#'  provided, variables are looked up in the environment of the formula.
#' @rdname logitreg
#' @importFrom stats model.frame model.matrix model.response
logitreg.formula <- function(design, data = list(), ...) {
  # no input checks for data, this can be anything or even missing --
  # let model.frame deal with it.
  mf <- model.frame(formula = design, data = data)
  design <- model.matrix(attr(mf, "terms"), data = mf)
  response <- model.response(mf)

  if (is.factor(response)) {
    # factor(response, exclude=NULL) drops unused levels.
    if (length(levels(factor(response, exclude = NULL))) != 2) {
      stop("<response> is not a factor with 2 levels.")
    }
    response <- as.numeric(response) - 1
  }

  logitreg.default(design, response, ...)
}
