#' @include logitreg.R
NULL

#' Predicted/fitted values from logitreg-objects
#'
#' @param object a fitted object of class `logitreg``
#' @param type the type of predictions or fitted  values required.
#'  The default ("link") is on the  scale of the linear predictor; the
#'  alternative "response" gives the estimated or predicted probabilities.
#'  The "terms" option returns a matrix giving the predicted values of each
#'  term in the model formula on the linear predictor scale.
#' @param ... not used
#' @return a vector or matrix of fits or predictions
#' @export
#' @importFrom stats qlogis fitted
fitted.logitreg <- function(object, newdata,
                            type = c("link", "response", "terms"), ...) {
  type <- match.arg(type)

  switch(
      type,
      "link" = qlogis(object$fitted),
      "response" = object$fitted,
      "terms" = t(object$coefficients * t(object$data$design))
  )
}


#' @param newdata a model matrix. If missing, defaults to original data.
#' @rdname fitted.logitreg
#' @export
predict.logitreg <- function(object, newdata,
                             type = c("link", "response", "terms"), ...) {
  type <- match.arg(type)

  # TODO: input checking
  #        does newdata look like the original design matrix?
  #        same number of columns? same column names and types?
  if (missing(newdata)) {
    return(fitted(object, type = type))
  }

  if (type == "terms") {
    return(t(object$coefficients * t(newdata)))
  }

  predictions <- newdata %*% object$coefficients
  switch(
      type,
      "link" = predictions,
      "response" = logistic(predictions)
  )
}

#' Plot method for logitreg objects
#'
#' @param x an object inheriting from class `logitreg``
#' @param type defaults to "roc" (an ROC curve using **`{ROCR}`**), "boxplot"
#'   yields a grouped [graphics::boxplot()] of fitted probabilities.
#' @param ... additional arguments for `boxplot``
#' @method plot logitreg
#' @seealso [ROCR::plot.performance()]
#' @importFrom ROCR performance prediction plot
#' @importFrom graphics boxplot
plot.logitreg <- function(x, type = c("roc", "boxplot"), ...) {
  type <- match.arg(type)

  fitted <- fitted(x, type = "response")
  true <- x$data$response

  if (type == "boxplot") {
    boxplot(fitted ~ true, ylab = "P(response=1)", xlab = "response", ...)
  } else {
    # see ROCR::performance for details.
    # ROC curve shows false positive rate vs. true positive rate.
    roc <- performance(prediction(fitted, true),
      measure = "tpr",
      x.measure = "fpr"
    )
    plot(roc)
  }
}
