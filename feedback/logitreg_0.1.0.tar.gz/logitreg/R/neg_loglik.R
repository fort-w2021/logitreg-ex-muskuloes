# numerically stable implementation of logistic function
#' @importFrom stats plogis
logistic <- function(x) plogis(x)

#' Negative log-likelihood for logistic regression
#'
#' Computes the negative log-likelihood for logistic regression
#' \deqn{
#'   -\ell(\beta; y, X) = - \sum_i y_i\log(p_i) + (1-y_i)\log(1-p_i)
#' }
#' or its gradient
#' \deqn{
#'   \frac{\partial - \ell(\beta; y, X)}{\partial \beta} = - (y - p)^T X
#' }
#' with \eqn{p = g(X \beta)} and \eqn{g(x) = \frac{1}{1+\exp(-x)}} for design
#' matrix \eqn{X=}`design`, coefficient vector \eqn{\beta=}`coef` and
#' response vector \eqn{y=}`response`.
#'
#' @param coef the regression coefficients
#' @param design the design matrix
#' @param response the response vector
#' @return the value of the negative log-likelihood (gradient)
#' @export
neg_loglik <- function(coef, design, response) {
  probs <- logistic(design %*% coef)

  -sum(response * log(probs) + (1 - response) * log(1 - probs))
}

# use @rdname to merge the documentation for neg_loglik and
# neg_loglik_deriv into a single file since their arguments are identical and
# their tasks are closely related:

#' @rdname neg_loglik
#' @export
neg_loglik_deriv <- function(coef, design, response) {
  probs <- logistic(design %*% coef)
  -t(response - probs) %*% design
}
