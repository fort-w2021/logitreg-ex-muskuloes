# Generate synthetic data sets for tests.
# q_numeric gaussian variables (~N(0,1)) and
# q_factor dummy variables.
# Returns list(x, y, b): design, response, true coefs or
#   data.frame with attribute("b").
#' @importFrom stats rnorm runif rbinom
sim_data <- function(n = 1.5e3, q_numeric = 3, q_factor = 0, seed = NULL,
                     dataframe = FALSE) {
    # set RNG seed for reproducibility:
    if (!is.null(seed)) set.seed(seed)

    q <- 1 + q_numeric + q_factor

    design <- matrix(0, nrow = n, ncol = q)
    design[, 1] <- 1
    design[, seq_len(q_numeric) + 1] <- matrix(rnorm(n * q_numeric), nrow = n)
    if (q_factor) {
        # add binary factors
        dummies <- matrix(sample(c(0, 1), n * q_factor, replace = TRUE),
                          nrow = n
        )
        design[, -seq_len(1 + q_numeric)] <- dummies
    }

    coef <- runif(q, min = -3, max = 3)

    probabilities <- logistic(design %*% coef)
    response <- rbinom(n, prob = probabilities, size = 1)

    if (!dataframe) {
        return(list(x = design, y = response, b = coef))
    }
    return(
        structure(
            data.frame(y = response, design[, -1, drop = FALSE]),
            "b" = coef))
}
